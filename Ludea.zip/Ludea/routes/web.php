<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes(); //using routes

############
## PUBLIC ##
############
Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/category/{catId}', [App\Http\Controllers\HomeController::class, 'indexByCategory'])->name('homeByCategory');
Route::post('/', [App\Http\Controllers\HomeController::class, 'doQuizById']);
Route::get('/who-am-i', [App\Http\Controllers\HomeController::class, 'identify'])->name('identify'); // get the username
Route::post('/who-am-i', [App\Http\Controllers\HomeController::class, 'identified'])->name('identified'); // store the username
Route::get('/flush', [App\Http\Controllers\HomeController::class, 'flush'])->name('flush'); // flush the session

Route::get('/quiz/{quizId}', [App\Http\Controllers\HomeController::class, 'doQuiz'])->name('doQuiz');
Route::post('/quiz/{quizId}', [App\Http\Controllers\HomeController::class, 'calculateScore'])->name('finishQuiz');
Route::get('/quiz/{quizId}/scoreboard', [App\Http\Controllers\HomeController::class, 'viewScore'])->name('viewScore');

Route::get('/about-us', [App\Http\Controllers\HomeController::class, 'about']);

#################
## LOGGED USER ##
#################
Route::get('/home', [App\Http\Controllers\logged\LoggedController::class, 'index'])->name('loggedHome');

Route::get('/new-set', [App\Http\Controllers\logged\LoggedController::class, 'newSet'])->name('newSet');
Route::post('/new-set', [App\Http\Controllers\logged\LoggedController::class, 'postNewSet'])->name('postNewSet');
Route::get('/edit-set/{setId}', [App\Http\Controllers\logged\LoggedController::class, 'editSet'])->name('editSet');
Route::post('/edit-set/{setId}', [App\Http\Controllers\logged\LoggedController::class, 'updateSet'])->name('updateSet');
Route::delete('/delete-set/{setId}', [App\Http\Controllers\logged\LoggedController::class, 'deleteSet'])->name('deleteSet');

Route::get('/edit-set/{setId}/new-item', [App\Http\Controllers\logged\LoggedController::class, 'newItem'])->name('newItem');
Route::post('/edit-set/{setId}/new-item', [App\Http\Controllers\logged\LoggedController::class, 'postNewItem'])->name('postNewItem');
Route::get('/edit-set/{setId}/edit-item/{itemId}', [App\Http\Controllers\logged\LoggedController::class, 'editItem'])->name('editItem');
Route::post('/edit-set/{setId}/edit-item/{itemId}', [App\Http\Controllers\logged\LoggedController::class, 'updateItem'])->name('updateItem');
Route::delete('/edit-set/{setId}/delete-item/{itemId}', [App\Http\Controllers\logged\LoggedController::class, 'deleteItem'])->name('deleteItem');

Route::get('/duplicate-set', [App\Http\Controllers\logged\LoggedController::class, 'showAllSet'])->name('showAllSet');
Route::get('/duplicate-set/{setId}', [App\Http\Controllers\logged\LoggedController::class, 'duplicateSet'])->name('duplicateSet');

###########
## ADMIN ##
###########
Route::get('/admin', [App\Http\Controllers\admin\AdminController::class, 'index'])->name('home_admin');

Route::get('/admin/category', [\App\Http\Controllers\admin\AdminController::class, 'viewCategory'])->name('viewCategory');
Route::post('/admin/category', [\App\Http\Controllers\admin\AdminController::class, 'addCategory'])->name('newCategory');
Route::post('/admin/category/{catId}', [\App\Http\Controllers\admin\AdminController::class, 'updateCategory'])->name('updateCategory');
Route::delete('/admin/category/{catId}', [\App\Http\Controllers\admin\AdminController::class, 'deleteCategory'])->name('deleteCategory');

Route::get('/admin/logs', [\App\Http\Controllers\admin\AdminController::class, 'viewLogs'])->name('viewLogs');