//__________________________________________________________________________________Ghost Element Mode__
function summonGhost(){
    var style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = '* { background: #000 !important; background-color: #000 !important; color: #0f0 !important; border: 1px solid #f00 !important}';
    document.getElementsByTagName('head')[0].appendChild(style);
}

//___________________________________________________________________________________Alert Auto Fade Out__

setTimeout(function(){
    $('.alert-dismissible').fadeOut();
}, 3000);

//___________________________________________________________________________________Who Am I page__

$(document).ready(function(){
    $(".whoami").css("opacity", 1);
});

//__________________________________________________________________________________Category Table__

$(document).ready(function(){
    var tableCate = $('#tableCate').DataTable();

    tableCate.on('click', '.edit-btn', function(){ //triggered pas tekan button .edit-btn
        $tr = $(this).closest('tr'); //fetch tr terdekat
        if($($tr).hasClass('child')){
            $tr = $tr.prev('parent');
        }

        var dataCate = tableCate.row($tr).data(); //fetch data dlm tr

        console.log(dataCate);
    });
});

//__________________________________________________________________________________Log Table__

$(document).ready(function(){
    var tableLog = $('#tableLog').DataTable();
});

//___________________________________________________________________________________Get selected category from search__

if($('#selectCate').change(function(){
    //$('#inputBar').val($(this).find('option:selected').val());
    var target = $(this).find('option:selected').val();
    if(target!=0){
        window.location.href = "/category/" + target;
    }else{
        window.location.href = "/";
    }
}));