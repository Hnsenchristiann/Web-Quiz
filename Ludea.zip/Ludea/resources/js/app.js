require('./bootstrap');
require('./jquery.min');
require('./datatables.min');