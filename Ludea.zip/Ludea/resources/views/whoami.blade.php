@extends('layouts.app')

@section('content')
<div style="display: block">
    <div style="opacity: 0; transition: opacity 1s ease-in; width: 80%; padding: 20px; float: left;" class="whoami">
        <div class="bg-white px-4 py-4" style="border-radius: 10px; box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);">
            <h3>Welcome to LUDEA.</h3>
            <h3>Unlike your classroom, Quizzes here are really InTeReStInG!</h3>
            <h3>But before having fun, do you mind telling me what your name is?</h3>
        </div>
    </div>
</div>
<div style="display: block">
    <div style="opacity: 0; transition: opacity 2s ease-in; width: auto; max-width: 80%; padding: 20px; float: right;" class="whoami">
        <div class="bg-white px-4 py-4" style="border-radius: 10px; box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);">
            <form method="POST" action="{{ route('identified') }}">
                @csrf
                <h3>Sure, no problem!</h3>
                <h3 style="display: inline">My name is </h3>
                <input type="text" class="px-2" name="username" size="10" style="display: inline-block; width: auto; font-size: 1.5rem; border: none; border-bottom: 3px dotted #000; background: #eee">
                <button type="submit" class="btn btn-success my-2 mx-2" style="display: inline-block">Go!</button>
            </form>
        </div>
    </div>
    
</div>
@endsection