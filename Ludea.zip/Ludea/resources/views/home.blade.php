@extends('layouts.app')

@section('content')
@if(session()->has('message'))
    <div class="alert alert-danger alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        {{ session()->get('message') }}
    </div>
@endif
<div class="row container mx-auto px-3">
    {{-- <!-- Result Count & Sort --> --}}
    <div class="container col-md-6" style="float: left;">
        <h4 class="text-blue" style="text-transform: uppercase;">{{ isset($categoryName) ? $categoryName.' Quizzes' : 'All Quizzes' }}</h4>
        <p>Showing {{count($rowQuestionSet)}} of {{$rowQuestionSetCount}} quizzes</p>
    </div>
    <div class="container col-md-6 form-group text-right" style="float: right">
        @if(!$rowCategory->isEmpty())
        <select id="selectCate" class="form-control" style="width: 50%; display: inline-block;">
            <option selected disabled>Sort by category</option>
            <option value="0">All Categories</option>
            @foreach($rowCategory as $cate)
            <!--<option value="{{$cate->id}}">{{$cate->category_name}}</option>-->
            <option value="{{$cate->id}}">
                <a href="{{ route('homeByCategory', [$cate->id]) }}">{{ $cate->category_name }}</a>
            </option>
            @endforeach
        </select>
        @endif
    </div>
</div>
<div class="row" style="margin: 0 auto;">
    <div class="col-md-3 col-sm-4 col-8 px-4 py-4 text-center the-container" style="background-color: #fff;">
        <h4>Insert quiz id below!</h4>
        <form method="POST" action="{{url('/')}}">
            @csrf
            <input type="text" name="quizId" class="form-control" style="display: inline-block; width: 75%;" placeholder="Ex: 321">
            <button type="submit" class="btn btn-success" style="display: inline-block; width: 20%">Go!</button>
        </form>
    </div>
</div>
<div class="container-all-quiz">
    <div class="row">
        @if(!$rowQuestionSet->isEmpty())
            @foreach($rowQuestionSet as $row)
                <a class="col-md-6" href="{{url('/quiz/'.$row->id)}}">
                    <div class="quiz-each">
                        <p style="margin-bottom: 0.5rem">{{$row->set_title}}</p>
                        <small>{{$row->set_description}}</small>
                        @if(!$rowUser->isEmpty())
                        @foreach($rowUser as $wow)
                        @if($row->set_author_id == $wow->id)
                        <br><small>Author: {{$wow->name}}</small>
                        @endif
                        @endforeach
                        @endif
                    </div>
                </a>
            @endforeach
        @endif
    </div>
</div>
<div class="row" style="margin: 0;">
    <div class="col-md-12 d-flex justify-content-center pt-5">
        {{ $rowQuestionSet->onEachSide(3)->links() }}
    </div>
</div>
@endsection