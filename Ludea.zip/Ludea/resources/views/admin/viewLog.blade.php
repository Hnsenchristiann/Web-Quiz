@extends('layouts.app_admin')

@section('content')
<div class="container">
    <div class="mt-4 the-container ctn-white px-4 py-4">
        <table class="table" id="tableLog">
            <thead>
                <tr>
                    <th>Log ID</th>
                    <th>Subject</th>
                    <th>Related Admin</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @if(!$rowLog->isEmpty()) <!-- Check if it has value -->
                    @foreach($rowLog as $row)
                    <tr>
                        <td>{{ $row->id }}</td>
                        <td> {{$row->log_subject}}</td>
                        @if(!$rowUser->isEmpty())
                            @foreach($rowUser as $admin)
                                @if($row->log_admin_id == $admin->id)
                                <td> {{$admin->name}}</td>
                                @endif
                            @endforeach
                        @endif
                        <td>
                            <button class="btn btn-primary">Update</button>
                            <a href="#">
                                <div class="btn btn-danger mb-1 edit-btn">Delete</div>
                            </a>
                        </td>
                    </tr>
                    @endforeach
                @else
                    <tr>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                @endif
            </tbody>
        </table>
    </div>

</div>
@endsection
