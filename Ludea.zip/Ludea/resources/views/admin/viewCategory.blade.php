@extends('layouts.app_admin')

@section('content')
<div class="container">
    @if(session()->has('message'))
        <div class="alert alert-success alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            {{ session()->get('message') }}
        </div>
    @endif
    <div class="mt-4 col-md-8" >
        <div class="the-container ctn-white px-4 py-4">
            <form action="{{ route('newCategory') }}" method="POST">
                <h4 class="mb-4">New Category</h4>
                @csrf
                <div class="form-group">
                    <label>Category Name</label>
                    <input type="text" name="catName" class="form-control" placeholder="Enter the name of category" required>
                </div>
                <button type="submit" class="btn btn-primary mt-3">Add Category</button>
            </form>
        </div>
    </div>
    <div class="mt-4 the-container ctn-white px-4 py-4">
        <table class="table" id="tableCate">
            <thead>
                <tr>
                    <th>Category ID</th>
                    <th>Category Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @if(!$rowCategory->isEmpty()) <!-- Check if it has value -->
                    @foreach($rowCategory as $row)
                    <tr>
                        <td>{{ $row->id }}</td>
                        <!--<td> {{$row->category_name}}</td>-->
                        <form action="{{ route('updateCategory', [$row->id]) }}" method="POST">
                        @csrf
                        <td>
                            <input type="text" class="form-control" name="catName" value="{{$row->category_name}}">
                        </td>
                        <td>
                            <button class="btn btn-primary" type="submit">Update</button>
                            </form>
                            <form action="{{ route('deleteCategory', [$row->id]) }}" method="POST" style="margin-top: 10px">
                                @csrf
                                <input type="hidden" name="_method" value="delete">
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                @else
                    <tr>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                @endif
            </tbody>
        </table>
    </div>

</div>
@endsection
