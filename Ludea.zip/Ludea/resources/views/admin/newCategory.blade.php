@extends('layouts.app')

@section('content')
<div class="container">
    <div class="mt-4 col-md-8" style="margin:0 auto;">
        <div>
            <form action="{{ url('admin/category') }}" method="POST">
                <h4>New Category</h4>
                @csrf
                <div class="form-group">
                    <label>Category Name</label>
                    <input type="text" name="catName" class="form-control" placeholder="Enter the name of category" required>
                </div>
                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
        <!-- {{-- <div>
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Title</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($rowQuestionSet as $row)
                    <tr>
                        <td>{{ $row->id }}</td>
                        <td> {{$row->question_set_title}} </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div> --}} -->
    </div>
</div>
@endsection
