@extends('layouts.app_admin')

@section('content')
<div class="container">
    <div class="mt-4">
        <a href="{{ route('viewLogs') }}">
            <div class="btn btn-primary">
                View Admin Logs
            </div>
        </a>
        <a href="{{ route('viewCategory') }}">
            <div class="btn btn-primary">
                View Categories
            </div>
        </a>
    </div>
</div>
@endsection
