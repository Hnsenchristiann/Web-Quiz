@extends('layouts.app_dark')

@section('content')
<div class="container" style="width: 80%; margin: 0 auto;">
	<div class="container container-about">
		<h1 class="title">About Us</h1>
		<div class="wrapper row">
			<div class="content col-md-8">
				<h3>LUDEA merupakan kepanjangan dari Lulus Dengan A karena di harapkan setelah menyelesaikan project
					quiz web ini, arti lain LUDEA adalah Level Up Idea yang berarti idea di dalam mengerjakan quiz di level up dengan ada nya web ini</h3>
				<p>Kurangnya efektivitas dalam proses belajar mengajar menjadi masalah yang menghambat perkembangan pendidikan di Indonesia. Efektivitas menjadi kunci dalam kelancaran kegiatan transaksi ilmu, dengan kegiatan transaksi ilmu yang meningkat, maka perkembangan pendidikan di Indonesia pun akan meningkat, salah satu faktor yang menghambat transaksi ilmu dan efektivitasnya adalah keterbatasan media dalam kegiatan transaksi ilmu. Dengan adanya web based quiz ini, 
				diharapkan transaksi ilmu dapat dilakukan lebih efisien dan membantu baik para pengajar dan murid dalam proses pembelajaran</p>
				<ul>
					<li><span><i class="fas fa-circle-notch"></i>Hansen Christian Zaputa (UI Designer & Front End),</span></li>
					<li><span><i class="fas fa-circle-notch"></i>Sebastian (UI designer & Front End),</span></li>
					<li><span><i class="fas fa-circle-notch"></i>Charles (BackEnd Developer),</span></li>
				</ul>
				<div class="button">
					<a href="">Read More</a>
				</div>
				<div class="social">
					<a href=""><i class="fab fa-facebook-f"></i></a>
					<a href=""><i class="fab fa-twitter"></i></a>
					<a href=""><i class="fab fa-instagram"></i></a>
				</div>
			</div>
			<div class="col-md-1"></div>
			<div class="image-section col-md-3">
				<img src="{{asset('imgs/logo.png')}}" />
			</div>
		</div>
	</div>
</div>
@endsection