@extends('errors::minimal')
{{--
@section('title', __('Not Found'))
@section('code', '404')
@section('message', __('Not Found'))
--}}
@section('title', 'Ludea')
@section('message', 'Going somewhere?')