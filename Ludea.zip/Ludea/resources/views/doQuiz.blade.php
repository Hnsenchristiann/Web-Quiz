@extends('layouts.app_plain')

@section('content')
<link rel="stylesheet" href="{{asset('/css/StyleS.css')}}">
<div class="container">
    {{-- <!--
    <div class="mt-4 col-md-8" style="margin:0 auto;">
        <div>
            <form action="" method="POST">
                <h4 class="mb-5">{{$rowQuestionSet['set_title']}}</h4>
                @csrf
                
                @for($i = 0; $i < count($rowQuestionItem); $i++)
                <div class="form-group">
                    <label>{{$itemQue[$i]}}</label>

                    @for($j = 0; $j < 4; $j++)
                        <div>
                            <input type="radio" name="ans{{$i}}" id="ans{{$i}}_{{$j}}">
                            <label for="ans{{$i}}_{{$j}}">{{$itemCho[$i][$j]}}</label>
                            @if($j+1 == $itemAns[$i])
                            <small>(Answer)</small>
                            @endif
                        </div>
                    @endfor

                </div>
                @endfor

                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
    </div>
    --> --}}



    <!--Start Quiz Button-->
    <div class="start_btn">
        <button>Mulai Quiz</button>
    </div>

    <!--Info Box-->
    <div class="info_box">
        <div class="info_title">
            <span>Hayo di Baca Aturannya, {{$username}}</span>
        </div>
        <div class="info_list">
            <div class="info">1. Kamu cuma memiliki waktu <span>15 detik</span> untuk setiap soal</div>
            <div class="info">2. ketika kamu telah memilih jawaban, kamu tidak bisa menggantinya</div>
            <div class="info">3. kamu tidak bisa keluar dari quiz ketika sedang mengerjakannya</div>
            <div class="info">4. kamu akan mendapatkan point dari jumlah jawaban yang benar</div>
            <div class="info">5. Ketika waktu habis kamu tidak bisa memilih jawaban lagi</div>
        </div>
        <div class="buttons">
            <button class="quit">Keluar dari Quiz</button>
            <button class="restart">Lanjutkan</button>
        </div>
    </div>

    <!--Quiz Box-->
    <div class="quiz_box">
        <header>
            <div class="title">WAW BAGUS BANGET</div>
            <div class="timer">
                <div class="time_text">Sisa Waktu</div>
                <div class="timer_sec">15</div>
            </div>
            <div class="time_line"></div>
        </header>
        <section>
            <div class="que_text">
                <!--<span>Siapa Nama Aplikasi Pembuat Website ini?</span>-->
            </div>
            <div class="option_list">
                <!--<div class="option">
                    <span>Charles, Sebastian, dan Hansen</span>
                    <div class="icon tick"><i class="fas fa-check"></i></div>
                </div>
                <div class="option">
                    <span>Supra, Tati, dan Tuti</span>
                    <div class="icon cross"><i class="fas fa-times"></i></div>
                </div>
                <div class="option">
                    <span>Jono, Joni, dan Andi</span>
                </div>
                <div class="option">
                    <span>Jono, Handi, dan Andi</span>
                </div>-->
            </div>
        </section>

        <!--QUiz Box Footer-->
        <footer>
            <div class="total_que">
               <!-- <span><p>2</p>Dari<p>5</p>Soal</span>-->
            </div>
            <button class="next_btn">Next Que</button>
        </footer>
    </div>

    <!--Result Box-->
    <div class="result_box">
        <div class="icon">
            <i class="fas fa-crown"></i>
        </div>
        <div class="complete_text">Kamu Telah Menyelesaikan Quiz</div>
        <div class="score_text">
            <!--<span>maaf, kamu hanya dapat <p>2</p>dari<p>5</p></span>-->
        </div>
        <div class="buttons">
            <button class="restart">Ulang Quiz</button>
            <button class="quit">Keluar Quiz</button>
            {{-- <!--
                Nanti disini ditaro form dgn hidden input, isinya username sama score, trus nge-post ke halaman score
            --> --}}
            <form method="POST" action="{{ route('finishQuiz', [$quizId]) }}">
                @csrf
                <input type="hidden" name="correct" id="correct">
                <input type="hidden" name="total" id="total">
                <button type="submit">Score</button>
            </form>
        </div>
    </div>

</div>
<script>
    let rawQuestions = <?php echo json_encode($rawQuestions); ?>;
    //console.log("rawQuestions = " + JSON.stringify(rawQuestions, null, 2));

    <?php
    // SCRIPT CONTAINING QUESTION ITEM DATA
        echo 'let questions = [';
        foreach($rawQuestions as $raw){
            echo '{';
            echo 'numb: ' . $raw[0] . ',';
            echo 'question: "' . $raw[1] . '",';
            //echo 'answer: "' . $raw[2] . '",';
            echo 'answer: "' . $raw[3][($raw[2]-1)] . '",';
            echo 'options: [';
            for($i=0; $i<4; $i++){
                echo '"'.$raw[3][$i].'"';
                if($i<3){
                    echo ', ';
                }
            }
            echo ']},';
        }
        echo '];';
    ?>

    //console.log("questions = " + JSON.stringify(questions, null, 2));
</script>
<script src="{{asset('/js/script.js')}}"></script>
@endsection
