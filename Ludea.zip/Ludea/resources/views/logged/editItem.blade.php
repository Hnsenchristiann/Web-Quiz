@extends('layouts.app')

@section('content')
<div class="container">
    <div class="mt-4 col-md-8 px-4 py-4 the-container ctn-color">
        <div>
            <form action="{{ route('updateItem', [$setId, $itemId]) }}" method="POST">
                <h4>Edit Question</h4>
                @csrf
                <div class="form-group">
                    <label>Quiz ID</label>
                    <input type="text" name="quizId" class="form-control" required disabled value="{{$setId}}">
                </div>
                <div class="form-group">
                    <label>Question</label>
                    <textarea type="text" name="question" class="form-control" required>{{$itemQuestion}}</textarea>
                </div>
                <div class="form-group">
                    <label>Choices</label>
                    <div class="row">
                        <div class="col-md-3">
                            <input type="text" name="choice1" class="form-control" required placeholder="A." value="{{$itemChoices[0]}}">
                        </div>
                        <div class="col-md-3">
                            <input type="text" name="choice2" class="form-control" required placeholder="B." value="{{$itemChoices[1]}}">
                        </div>
                        <div class="col-md-3">
                            <input type="text" name="choice3" class="form-control" required placeholder="C." value="{{$itemChoices[2]}}">
                        </div>
                        <div class="col-md-3">
                            <input type="text" name="choice4" class="form-control" required placeholder="D." value="{{$itemChoices[3]}}">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label>Answer</label>
                    <select name="answer" class="form-control" style="width: 25%" value="{{$itemAnswer}}">
                        <option value='1'>A</option>
                        <option value='2'>B</option>
                        <option value='3'>C</option>
                        <option value='4'>D</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
        <!-- {{-- <div>
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Title</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($rowQuestionSet as $row)
                    <tr>
                        <td>{{ $row->id }}</td>
                        <td> {{$row->question_set_title}} </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div> --}} -->
    </div>
</div>
@endsection
