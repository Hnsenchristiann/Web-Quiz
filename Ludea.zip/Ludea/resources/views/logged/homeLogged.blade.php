@extends('layouts.app')

@section('content')
<div class="container">

    @if(session()->has('message'))
        <div class="alert alert-success alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            {{ session()->get('message') }}
        </div>
    @endif

    <div class="row">
        <!-- Left Side -->
        <div class="col-md-4 container-logged-left">
            <!-- Do Quiz -->
            <div class="homeLogged-inputCode mt-4">
                <form>
                    <h4>Masukkan Kode Soal</h4>
                    <div class="input-group">
                        <input class="myInput mb-3" type="text" />
                        <input type="submit" class="btn btn-success" value="Go !"/>
                    </div>
                </form>
            </div>

            <div class="homeLogged-createBtn mt-5">
                <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#createQuizModal">Buat Soal</button>
            </div>

            <!-- Modal Buat Soal -->
            <div id="createQuizModal" class="modal fade" role="dialog">
                <div class="modal-dialog"> 
                    <!-- Modal content-->
                    <div class="modal-content" style="background: linear-gradient(45deg, rgb(93, 235, 219), rgba(241, 237, 8, 0.294)); color: white">
                        <div class="modal-header">
                            <h4 class="modal-title">Create a Quiz</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <div class="btn1 mb-3">
                                <a href="{{ route('showAllSet') }}">
                                    <div class="btn btn-primary">
                                        Use an Existing Question Set Template
                                    </div>
                                </a>
                            </div>
                            <div class="btn2">
                                <a href="{{ route('newSet') }}">
                                    <div class="btn btn-primary">
                                        Create a New One
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Side -->
        <div class="col-md-8">
            <!-- Question Set List -->
            <div class="mt-4">
                <table class="table" style="background: #fff; border-radius: 15px; box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);">
                    <thead>
                        <tr>
                            <th>Set ID</th>
                            <th>Set Title</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if(!$rowQuestionSet->isEmpty()) <!-- Check if it has value -->
                            @foreach($rowQuestionSet as $row)
                            <tr>
                                <td>{{ $row->id }}</td>
                                <td> {{$row->set_title}} </td>
                                <td>
                                    <!-- {{-- <button class="btn btn-primary mb-1">Edit Questions</button> --}} -->
                                    <a href="{{ route('editSet', [$row->id]) }}">
                                        <div class="btn btn-primary mb-1">Edit Questions</div>
                                    </a>
                                    <form action="{{ route('deleteSet', [$row->id]) }}" method="POST">
                                        @csrf
                                        <input type="hidden" name="_method" value="delete">
                                        <button type="submit" class="btn btn-danger">Delete Quiz</button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        @else
                            <tr>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                            </tr>
                        @endif
                    </tbody>
                </table>
            </div>
            
        </div>

    </div>
</div>
@endsection
