@extends('layouts.app')

@section('content')
<div class="container">
    <div class="mt-4 col-md-8 px-4 py-4 the-container ctn-color">
        <div>
            <form action="{{ route('postNewSet') }}" method="POST">
                <h4>New Quiz</h4>
                @csrf
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="setTitle" class="form-control" placeholder="Enter the title of the quiz" required>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="setDesc" class="form-control" required></textarea>
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <select name="setCat" class="form-control">
                    @if(!$rowCategory->isEmpty())
                        @foreach($rowCategory as $row)
                            <option value="{{$row->id}}">{{$row->category_name}}</option>
                        @endforeach
                    @else
                        <option value="0" disabled>No Category</option>
                    @endif
                    </select>
                </div>
                <div class="form-check my-3">
                    <input type="checkbox" name="setPrivacy" id="setPrivacy" class="form-check-input"> 
                    <label for="setPrivacy" label="form-check-label">Check if this question set is <strong>NOT</strong> for public use</label>
                </div>
                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
        <!-- {{-- <div>
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Title</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($rowQuestionSet as $row)
                    <tr>
                        <td>{{ $row->id }}</td>
                        <td> {{$row->question_set_title}} </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div> --}} -->
    </div>
</div>
@endsection
