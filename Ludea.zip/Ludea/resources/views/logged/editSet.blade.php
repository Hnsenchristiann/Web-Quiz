@extends('layouts.app')

@section('content')
<div class="container">
    @if(session()->has('message'))
        <div class="alert alert-success alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            {{ session()->get('message') }}
        </div>
    @endif
    <form action="{{ route('updateSet', [$setId]) }}" method="POST" class="the-container ctn-white py-4 px-4">
        @csrf
        <div class="row"> <!-- {{-- Quiz Header --}} -->
        
            @if(!empty($rowQuestionSet))
            <div class="form-group col-md-2">
                <label>Set ID</label>
                <input type="text" name="quizId" class="form-control" value="{{ $rowQuestionSet->id }}" disabled>
            </div>
            <div class="form-group col-md-10">
                <label>Set Title</label>
                <input type="text" name="setTitle" class="form-control" value="{{ $rowQuestionSet->set_title }}">
            </div>
            <div class="form-group col-md-12">
                <label>Set Description</label>
                <input type="text" name="setDesc" class="form-control" value="{{ $rowQuestionSet->set_description }}">
            </div>
            <div class="form-group col-md-6">
                <label>Set Author</label>
                <input type="text" name="setAuthor" class="form-control" value="{{$setAuthor}}" disabled>
            </div>
            <div class="form-group col-md-6">
                <label>Set Category</label>
                <select id="setCat" name="setCat" class="form-control">
                @if(!$rowCategory->isEmpty())
                    @foreach($rowCategory as $rowCat)
                        <option value="{{$rowCat->id}}">{{$rowCat->category_name}}</option>
                    @endforeach
                @else
                    <option value="0" disabled>No Category</option>
                @endif
                </select>
            </div>
            <div class="form-group col-md-6">
                <label>Set Published/Updated</label>
                <input type="text" name="setPublished" class="form-control" value="{{ $rowQuestionSet->updated_at->format('d M Y H:i A') }}" disabled>
            </div>
            <div class="form-check col-md-12 text-center my-3">
                <input type="checkbox" name="setPrivacy" id="setPrivacy" class="form-check-input"> 
                <label for="setPrivacy" label="form-check-label">Check if this question set is <strong>NOT</strong> for public use</label>
            </div>
            @endif
        </div>
        <div style="width: 100%; text-align: center">
            <button type="submit" class="btn btn-success">Update</button>
        </div>
    </form>
    <div class="mt-4"> <!-- {{-- Quiz Questions List --}} -->
        @if(!$rowQuestionItem->isEmpty())
        <table class="table the-container ctn-white py-4 px-4">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Questions</th>
                    <th>Choices</th>
                    <th>Answer</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($rowQuestionItem as $row)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $row->item_question}}</td>
                    <?php
                        $choice = explode("_", $row->item_choices);
                    ?>
                    <td>
                    @foreach($choice as $roww)
                        [{{ $roww }}]&nbsp;
                    @endforeach
                    </td>
                    <td>{{ $row->item_answer }}</td>
                    <td>
                        <a href="{{ route('editItem', [$setId, $row->id]) }}">
                            <div class="btn btn-primary">
                                Edit
                            </div>
                        </a>
                        <form action="{{ route('deleteItem', [$setId, $row->id]) }}" method="POST" style="margin-top: 10px">
                            @csrf
                            <input type="hidden" name="_method" value="delete">
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @endif
    </div>
    <div class="mt-4">
        <div style="width: 50%; text-align: center; margin: 0 auto">
            <a href="{{ route('newItem', [$setId]) }}">
                <div class="btn btn-primary">
                    Add a Question
                </div>
            </a>
            <a href="{{ route('loggedHome') }}">
                <div class="btn btn-success">
                    Done
                </div>
            </a>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        //change the set category
        $('#setCat').val("{{$setCat}}").change();
        //change the set privacy checkbox
        if({{$setPriv}}){
            $('#setPrivacy').prop("checked", true);
        }
    });
</script>
@endsection
