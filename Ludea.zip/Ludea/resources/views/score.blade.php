@extends('layouts.app_plain')

@section('content')
<div class="container" style="width: 80%; margin: 0 auto; text-align: center">
	<h1>Scoreboard</h1>
	<div class="x">
		
		<table class="table" border="2" style="width: 75%; margin: 0 auto">
			<thead>
				<tr>
					<th>Ranking</th>
					<th>Nama</th>
					<th>Nilai</th>
				</tr>
			</thead>
			<tbody>
				@if(!$rowScores->isEmpty())
					@foreach($rowScores as $row)
					<tr>
						<td>{{$loop->iteration}}</td>
						<td>{{$row->username}}</td>
						<td>{{$row->score}}</td>
					</tr>
					@endforeach
				@else
				<tr>
					<td>1</td>
					<td>John Doe</td>
					<td>100</td>
				</tr>
				<tr>
					<td>2</td>
					<td>Jane Doe</td>
					<td>95</td>
				</tr>
				<tr>
					<td>3</td>
					<td>Josh Doe</td>
					<td>90</td>
				</tr>
				<tr>
					<td>4</td>
					<td>Jenny Doe</td>
					<td>70</td>
				</tr>
				<tr>
					<td>5</td>
					<td>Jeff Doe</td>
					<td>40</td>
				</tr>
				@endif
			</tbody>
		</table>
	
	</div>
</div>
@endsection