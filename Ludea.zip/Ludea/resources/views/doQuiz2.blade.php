@extends('layouts.app')

@section('content')
<div class="container">
    <div class="mt-4 col-md-8" style="margin:0 auto;">
        <div>
            <form action="" method="POST">
                <h4 class="mb-5">{{$rowQuestionSet['set_title']}}</h4>
                @csrf
                
                @for($i = 0; $i < count($rowQuestionItem); $i++)
                <div class="form-group">
                    <label>{{$itemQue[$i]}}</label>

                    @for($j = 0; $j < 4; $j++)
                        <div>
                            <input type="radio" name="ans{{$i}}" id="ans{{$i}}_{{$j}}">
                            <label for="ans{{$i}}_{{$j}}">{{$itemCho[$i][$j]}}</label>
                            @if($j+1 == $itemAns[$i])
                            <small>(Answer)</small>
                            @endif
                        </div>
                    @endfor

                </div>
                @endfor

                <button type="submit" class="btn btn-primary">Save</button>
            </form>
        </div>
    </div>
</div>

<script>
    let rawQuestions = <?php echo json_encode($rawQuestions); ?>;
    console.log("rawQuestions = " + JSON.stringify(rawQuestions, null, 2));

    <?php
    // SCRIPT CONTAINING QUESTION ITEM DATA
        echo 'let questions = [';
        foreach($rawQuestions as $raw){
            echo '{';
            echo 'numb: ' . $raw[0] . ',';
            echo 'question: "' . $raw[1] . '",';
            echo 'answer: "' . $raw[2] . '",';
            echo 'options: [';
            for($i=0; $i<4; $i++){
                echo '"'.$raw[3][$i].'"';
                if($i<3){
                    echo ', ';
                }
            }
            echo ']},';
        }
        echo '];';
    ?>

    console.log("questions = " + JSON.stringify(questions, null, 2));
</script>
@endsection
