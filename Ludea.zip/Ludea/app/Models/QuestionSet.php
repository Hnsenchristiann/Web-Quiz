<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuestionSet extends Model
{
    use HasFactory;
    protected $table = 'question_sets';
    protected $fillable = [
        'set_title', 
        'set_description', 
        'set_category', 
        'set_author_id',
        'set_privacy',
    ];
}
