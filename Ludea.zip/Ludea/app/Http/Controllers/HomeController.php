<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\QuestionItem;
use App\Models\QuestionSet;
use App\Models\Category;
use App\Models\Scoreboard;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */

    public function index(Request $req)
    {
        $rowQuestionSet = QuestionSet::orderBy('created_at', 'asc')->where('set_privacy', 0)->paginate(8);
        $rowQuestionSetCount = count(QuestionSet::orderBy('created_at', 'asc')->where('set_privacy', 0)->paginate(10));
        $rowUser = User::orderBy('created_at', 'asc')->get();
        $rowCategory = Category::orderBy('created_at', 'asc')->get();
        if(Auth::check()){ // if user is logged, then use his logged name as username
            $req->session()->put('username', Auth::user()->name);
        }elseif(!$req->session()->has('username')){ // if user isn't logged and havent fill in his username
            return redirect()->route('identify');
        }
        return view('home', [
            'rowQuestionSet' => $rowQuestionSet,
            'rowQuestionSetCount' => $rowQuestionSetCount,
            'rowCategory' => $rowCategory,
            'rowUser' => $rowUser,
        ]);
    }

    public function indexByCategory(Request $req, $catId)
    {
        $rowQuestionSet = QuestionSet::orderBy('created_at', 'asc')->where('set_category', $catId)->where('set_privacy', 0)->paginate(10);
        $rowQuestionSetCount = count(QuestionSet::orderBy('created_at', 'asc')->where('set_category', $catId)->where('set_privacy', 0)->paginate(10));
        $rowCategory = Category::orderBy('created_at', 'asc')->get();
        $categoryName = Category::find($catId)->category_name;
        if(Auth::check()){ // if user is logged, then use his logged name as username
            $req->session()->put('username', Auth::user()->name);
        }elseif(!$req->session()->has('username')){ // if user isn't logged and havent fill in his username
            return redirect()->route('identify');
        }
        return view('home', [
            'rowQuestionSet' => $rowQuestionSet,
            'rowQuestionSetCount' => $rowQuestionSetCount,
            'rowCategory' => $rowCategory,
            'categoryName' => $categoryName,
        ]);
    }

    public function doQuizById(Request $req)
    {
        $this->validate($req, [
            'quizId' => 'required'
        ]);

        return redirect()->route('doQuiz', ['quizId' => $req->quizId]);
    }

    public function identify() // get the username
    { 
        return view('whoami');
    }

    public function identified(Request $req) // store the username
    {
        $this->validate($req, [
            'username' => 'required'
        ]);
        $req->session()->put('username', $req->input('username'));
        return redirect()->route('home');
    }

    public function flush(Request $req)
    {
        $req->session()->flush();
        return redirect()->back();
    }

    public function doQuiz($quizId, Request $req)
    {
        $rowQuestionSet = QuestionSet::where('id', $quizId)->first();
        $rowQuestionItem = QuestionItem::where('set_id', $quizId)->orderBy('created_at', 'asc')->get();
        $rowQuestions = QuestionItem::where('set_id', $quizId)->get();

        if(empty($rowQuestionSet)){
            // If there is no quiz with specified id
            // return view('unknown', [
            //     'quizId' => $quizId
            // ]);
            return redirect()->back()->with('message', 'Sorry, there is no quiz with specified ID');
        }
        
        if($rowQuestions->isEmpty()){
            // If quiz with specified id has no question yet
            return redirect()->back()->with('message', 'Sorry, the quiz with specified ID is not ready yet');
        }

        $num = 0;
        foreach($rowQuestions as $row){
            // question
            $itemQue[$num] = $row->item_question; 
            // choices
            $choiceExploded = explode('_', $row->item_choices);
            $choNum = 0; // for choices iteration
            foreach($choiceExploded as $choiceExp){
                $itemCho[$num][$choNum] = $choiceExp;
                $choNum++;
            }
            // answer
            $itemAns[$num] = $row->item_answer;
            $num++; //iteration
        }

        $i = 0;
        
        foreach($rowQuestions as $row){
            
            $que[$i][0] = $i+1; //penomoran
            $que[$i][1] = $row->item_question; //pertanyaan
            $que[$i][2] = $row->item_answer; //jawaban
            $choiceExploded = explode('_', $row->item_choices); //pilihan dipecah
            for($j=0; $j<4; $j++){ //loop pilihan
                $que[$i][3][$j] = $choiceExploded[$j];
            }
            $i++; //iteration
        }

        if($req->session()->has('username'))
        {
            $username = $req->session()->get('username');
        }

        return view('doQuiz', [
            'rowQuestionSet' => $rowQuestionSet,
            'rowQuestionItem' => $rowQuestionItem,
            'itemQue' => $itemQue,
            'itemCho' => $itemCho,
            'itemAns' => $itemAns,
            'rawQuestions' => $que,
            'username' => $username,
            'quizId' => $quizId
        ]);
    }

    public function calculateScore($quizId, Request $req)
    {
        $this->validate($req, [
            'correct' => 'required',
            'total' => 'required'
        ]);

        //calculate the score by dividing correct with total nums of questions
        $score = ($req->correct/$req->total)*100;
        
        $username = $req->session()->get('username');

        $input['set_id'] = $quizId;
        $input['username'] = $username;
        $input['score'] = round($score, 2);
        
        Scoreboard::create($input);

        return redirect()->reoute('viewScore', [$quizId]);
    }

    public function viewScore($quizId)
    {
        $rowScores = Scoreboard::orderBy('score', 'desc')->where('set_id', $quizId)->get();
        return view('score', [
            'rowScores' => $rowScores,
        ]);
    }
    
    public function about()
    {
        return view('about');
    }
}
