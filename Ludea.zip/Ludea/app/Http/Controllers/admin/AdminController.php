<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Log;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('is_admin');
    }

    public function index()
    {
        return view('admin/admin');
    }

    public function viewLogs()
    {
        $rowLog = Log::orderBy('created_at', 'asc')->get();
        $rowUser = User::orderBy('created_at', 'asc')->where('role', 'admin')->get();
        return view('admin/viewLog', [
            'rowLog' => $rowLog,
            'rowUser' => $rowUser,
        ]);
    }

    public function viewCategory()
    {
        $rowCategory = Category::orderBy('created_at', 'asc')->get();
        $admin = Auth::user();
        return view('admin/viewCategory', [
            'rowCategory' => $rowCategory,
            'admin' => $admin,
        ]);
    }

    public function addCategory(Request $req)
    {
        $this->validate($req, [
            'catName' => 'required'
        ]);

        $input['category_name'] = $req->catName;

        if(Category::create($input)){ // Creat log afterward
            $input_log['log_subject'] = 'Added a category';
            $input_log['log_admin_id'] = Auth::user()->id;
            $input_log['log_admin_name'] = Auth::user()->name;
            Log::create($input_log);
        }

        return back()->with('message', 'Category added successfully !');
    }

    public function updateCategory(Request $req, $catId)
    {
        $this->validate($req, [
            'catName' => 'required',
        ]);
        $cat = Category::find($catId);
        $cat->category_name = $req->catName;

        if($cat->save()){ // Create log afterward
            $input_log['log_subject'] = 'Updated a category - ['. $catId .'] ' . $req->catName;
            $input_log['log_admin_id'] = Auth::user()->id;
            $input_log['log_admin_name'] = Auth::user()->name;
            Log::create($input_log);
        }
        return redirect()->back()->with('message', 'Category updated !');
    }

    public function deleteCategory(Request $req, $catId)
    {
        $catName = Category::find($catId)->category_name;
        if(Category::find($catId)->delete()){
            $input_log['log_subject'] = 'Deleted a category - ['. $catId .'] '. $catName;
            $input_log['log_admin_id'] = Auth::user()->id;
            $input_log['log_admin_name'] = Auth::user()->name;
            Log::create($input_log);
        }
        return redirect()->back()->with('message', 'Category deleted !');
    }
}
