<?php

namespace App\Http\Controllers\logged;

use App\Http\Controllers\Controller;
use App\Models\QuestionItem;
use App\Models\QuestionSet;
use App\Models\Category;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoggedController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth'); // for login/regis user
    }

    // Home view
    public function index()
    {
        $user = Auth::user(); // Get the logged user

        error_log('Logged user : ['.Auth::id().'] '.Auth::user()->name); // Logging the logged user name

        // Get all quiz made by logged user
        $rowQuestionSet = QuestionSet::where('set_author_id', Auth::id())->orderBy('created_at', 'asc')->get();

        return view('logged/homeLogged', [
            'rowQuestionSet' => $rowQuestionSet,
            'user' => $user
        ]);
    }

    //Make new Question Set (Quiz)
    public function newSet(){
        $rowQuestionSet = QuestionSet::orderBy('created_at', 'asc')->get();
        $rowCategory = Category::orderBy('created_at', 'asc')->get();
        return view('logged.newSet', [
            'rowQuestionSet' => $rowQuestionSet,
            'rowCategory' => $rowCategory
        ]);
    }

    //Store/post new Question Set (Quiz)
    public function postNewSet(Request $req){
        $this->validate($req, [
            'setTitle' => 'required',
            'setDesc' => 'required|max:300',
            'setCat' => 'required',
        ]);

        $input['set_title'] = $req->setTitle;
        $input['set_description'] = $req->setDesc;
        $input['set_category'] = $req->setCat;
        $input['set_author_id'] = Auth::id();
        if($req->has('setPrivacy')){
            $input['set_privacy'] = 1;
        }

        QuestionSet::create($input);

        return redirect()->route('loggedHome');
    }

    //Edit question items in Question Set (Quiz)
    public function editSet($setId){
        $rowQuestionSet = QuestionSet::where('id', $setId)->first(); //get the question set (quiz)
        $rowQuestionItem = QuestionItem::where('set_id', $setId)->get(); //get the question items
        $rowCategory = Category::orderBy('created_at', 'asc')->get();
        $setAuthorObj = User::where('id', (QuestionSet::where('id', $setId)->first()->set_author_id))->first();
        $setAuthor = $setAuthorObj['name'];
        $setCat = $rowQuestionSet->set_category;
        $setPriv = $rowQuestionSet->set_privacy;
        
        return view('logged.editSet', [
            'rowQuestionSet' => $rowQuestionSet,
            'rowQuestionItem' => $rowQuestionItem,
            'rowCategory' => $rowCategory,
            'setId' => $setId,
            'setCat' => $setCat,
            'setPriv' => $setPriv,
            'setAuthor' => $setAuthor,
        ]);
    }

    // Update Question Set
    public function updateSet(Request $req, $setId){
        $this->validate($req, [
            'setTitle' => 'required',
            'setDesc' => 'required|max:300',
            'setCat' => 'required',
        ]);

        $input = QuestionSet::find($setId);

        $input['set_title'] = $req->setTitle;
        $input['set_description'] = $req->setDesc;
        $input['set_category'] = $req->setCat;
        $input['set_author_id'] = Auth::id();
        if($req->has('setPrivacy')){
            $input['set_privacy'] = 1;
        }else{
            $input['set_privacy'] = 0;
        }

        $input->save();

        return back()->with('message', 'Question Set updated successfully');
    }

    public function deleteSet($setId)
    {
        QuestionSet::find($setId)->delete();
        QuestionItem::where('set_id', $setId)->delete();
        return back()->with('message', 'Question Set removed successfully!');
    }

    //Add a new question in a quiz
    public function newItem($setId){
        return view('logged.newItem', [
            'setId' => $setId
        ]);
    }

    public function postNewItem(Request $req, $setId){
        $this->validate($req, [
            'question' => 'required',
            'choice1' => 'required',
            'choice2' => 'required',
            'choice3' => 'required',
            'choice4' => 'required',
            'answer' => 'required'
        ]);

        $input['set_id'] = $setId;
        $input['item_question'] = $req->question;
        $choices = $req->choice1 . '_' . $req->choice2 . '_' . $req->choice3 . '_' . $req->choice4;
        $input['item_choices'] = $choices;
        $input['item_answer'] = $req->answer;

        QuestionItem::create($input);

        //return redirect('/edit-set/'.$setId);
        return redirect()->route('editSet', ['setId' => $setId]);
    }

    public function editItem($setId, $itemId){
        //$rowQuestionSet = QuestionSet::where('id', $setId)->first(); // get the quiz
        $rowQuestionItem = QuestionItem::where('id', $itemId)->where('set_id', $setId)->first(); //get the question

        $itemQuestion = $rowQuestionItem['item_question'];
        $itemChoicesRaw = $rowQuestionItem['item_choices'];
        $itemChoices = explode('_', $itemChoicesRaw);
        $itemAnswer = $rowQuestionItem['item_answer'];

        return view('logged.editItem', [
            'setId' => $setId,
            'itemId' => $itemId,
            'itemQuestion' => $itemQuestion,
            'itemChoices' => $itemChoices,
            'itemAnswer' => $itemAnswer
        ]);
    }

    public function updateItem(Request $req, $setId, $itemId){
        $this->validate($req, [
            'question' => 'required',
            'choice1' => 'required',
            'choice2' => 'required',
            'choice3' => 'required',
            'choice4' => 'required',
            'answer' => 'required'
        ]);

        $input = QuestionItem::find($itemId); //getting the item from db

        $input['set_id'] = $setId;
        $input['item_question'] = $req->question;
        $choices = $req->choice1 . '_' . $req->choice2 . '_' . $req->choice3 . '_' . $req->choice4;
        $input['item_choices'] = $choices;
        $input['item_answer'] = $req->answer;

        $input->save();

        //return redirect('/edit-set/'.$setId);
        return redirect()->route('editSet', ['setId' => $setId]);
    }

    public function deleteItem($setId, $itemId)
    {
        QuestionItem::find($itemId)->delete();
        return back()->with('message', 'Item removed successfully!');
    }

    public function showAllSet()
    {
        $rowQuestionSet = QuestionSet::orderBy('created_at', 'asc')->where('set_privacy', 0)->get();
        return view('logged.showAllSet', [
            'rowQuestionSet' => $rowQuestionSet
        ]);
    }

    public function duplicateSet($setId)
    {
        // Get the original set
        $oriSet = QuestionSet::where('id', $setId)->first();

        error_log('Duplicating quiz ... ' . $oriSet);

        // Duplicate question set info__________________________________

        $cloneSet['set_title'] = $oriSet['set_title'] . ' [Duplicated]';
        $cloneSet['set_description'] = $oriSet['set_description'];
        $cloneSet['set_category'] = $oriSet['set_category'];
        $cloneSet['set_author_id'] = Auth::id();

        QuestionSet::create($cloneSet);

        // Duplicate question items_____________________________________
        
        $oriItems = QuestionItem::where('set_id', $setId)->get();
        $clonedSetId = QuestionSet::where('set_author_id', Auth::id())->orderBy('created_at', 'desc')->first()->id;
        
        foreach($oriItems as $oriItem)
        {
            error_log('Duplicating questions ... ' . $oriItem);
            
            $cloneItem['item_question'] = $oriItem['item_question'];
            $cloneItem['item_choices'] = $oriItem['item_choices'];
            $cloneItem['item_answer'] = $oriItem['item_answer'];
            $cloneItem['set_id'] = $clonedSetId;

            QuestionItem::create($cloneItem);
        }
        
        error_log('Quiz duplicated!');

        // HOW TO delete thru eloquent
        //QuestionSet::find(id)->delete();
        
        return redirect('/home')->with('message', 'Question Set duplicated!');

        /* HOW TO SUMMON message IN VIEW

            @if(session()->has('message'))
                <div class="alert alert-success">
                    {{ session()->get('message') }}
                </div>
            @endif
        */
    }
}
